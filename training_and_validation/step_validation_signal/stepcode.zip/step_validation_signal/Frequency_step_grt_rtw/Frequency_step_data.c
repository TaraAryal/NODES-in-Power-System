/*
 * Frequency_step_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Frequency_step".
 *
 * Model version              : 1.31
 * Simulink Coder version : 9.6 (R2021b) 14-May-2021
 * C source code generated on : Wed Nov 15 12:05:13 2023
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Frequency_step.h"
#include "Frequency_step_private.h"

/* Block parameters (default storage) */
P_Frequency_step_T Frequency_step_P = {
  /* Expression: 0.0
   * Referenced by: '<Root>/Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/deltaomega 1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Original w'
   */
  0.0,

  /* Expression: 20
   * Referenced by: '<Root>/Step'
   */
  20.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 0.2
   * Referenced by: '<Root>/Step'
   */
  0.2
};
